﻿using Avalonia.Media.Imaging;
using Avalonia.Platform;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using LightSync.Core.Captures;
using LightSync.UI.Plugins;
using LightSync.UI.ViewModels.Captures;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace LightSync.UI.ViewModels.Pages
{
    internal interface ISourcesPageViewModel : IPageViewModelBase { }

    internal partial class SourcesPageViewModel : PageViewModelBase, ISourcesPageViewModel
    {
        private readonly IPluginManager _pluginManager;
        private readonly ICaptureManager _captureManager;
        private readonly DispatcherTimer _bitmapUpdateTimer;

        private ICaptureLease? _captureLease;
        /*private WriteableBitmap? _back;
        private WriteableBitmap? _front;*/

        [ObservableProperty]
        public partial IReadOnlyList<CaptureInfoViewModel> Sources { get; private set; } = [];

        [ObservableProperty]
        public partial WriteableBitmap? PreviewBitmap { get; private set; }

        public SourcesPageViewModel(IPluginManager pluginManager, ICaptureManager captureManager)
        {
            _pluginManager = pluginManager;
            _captureManager = captureManager;

            _bitmapUpdateTimer = new(TimeSpan.FromMilliseconds(20), DispatcherPriority.Render, OnUpdateTimerTick);

            SynchroniseSourcesFromPlugins();
        }

        public override async Task OnUnloadedAsync(CancellationToken cancellationToken = default)
        {
        }

        private void SynchroniseSourcesFromPlugins()
        {
            Sources = [.. _pluginManager.CapturePlugins.SelectMany(plugin => plugin.CaptureInfoSource.Captures).Select(capture => new CaptureInfoViewModel(capture))];

            var testSource = Sources.LastOrDefault();
            if (testSource != null)
            {
                _captureLease = _captureManager.AcquireLease(testSource.AssociatedCaptureInfo);
            }
            //UpdateFilter();
        }

        private void OnUpdateTimerTick(object? sender, EventArgs e)
        {
            if (_captureLease == null)
                return;

            if (!_captureLease.CaptureFeed.HasData)
                return;
        }
    }
}
