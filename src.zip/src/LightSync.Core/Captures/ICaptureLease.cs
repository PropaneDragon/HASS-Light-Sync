﻿using LightSync.API.Captures;

namespace LightSync.Core.Captures
{
    public interface ICaptureLease : IDisposable
    {
        ICaptureFeed CaptureFeed { get; }
    }
}
