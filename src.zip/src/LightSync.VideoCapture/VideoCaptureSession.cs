﻿using LightSync.API.Captures;
using SeeShark;
using SeeShark.Device;

namespace LightSync.VideoCapture
{
    internal class VideoCaptureSession : ICaptureSession
    {
        private readonly int _maxWidth, _maxHeight;
        private readonly Display _display;

        private FrameConverter? _frameConverter;

        public int Width => _maxWidth;

        public int Height => _maxHeight;

        public CaptureFormat Format => CaptureFormat.Rgba32;

        public VideoCaptureSession(Display display, int maxWidth, int maxHeight)
        {
            _display = display;
            _maxWidth = maxWidth;
            _maxHeight = maxHeight;
        }

        public async Task<CaptureStatus> TryGetLatestFrameAsync(byte[] pixels, CancellationToken cancellationToken = default)
        {
            if (!_display.IsPlaying || _display.IsDisposed)
                return CaptureStatus.Ended;

            var status = _display.TryGetFrame(out var frame);
            if (status != SeeShark.Decode.DecodeStatus.NewFrame)
                return CaptureStatus.NoNewFrame;
            
            _frameConverter ??= new FrameConverter(frame.Width, frame.Height, PixelFormat.Rgba, _maxWidth, _maxHeight);

            var convertedFrame = _frameConverter.Convert(frame);
            if (!convertedFrame.RawData.TryCopyTo(pixels))
                return CaptureStatus.Ended;

            return CaptureStatus.Ok;
        }

        public async ValueTask DisposeAsync()
        {
            _display.StopCapture();
            _display.Dispose();
        }
    }
}
